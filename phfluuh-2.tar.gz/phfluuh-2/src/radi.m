%
%
%
%

lenswidth = input('lenswidth: ');
imagewidth = input('imagewidth: ');
%lenswidth = 0.98;
%imagewidth = 2048;
kx = lenswidth/imagewidth;


rstar = kx * input('The calculated values: ');
r1 = kx * input('The first corner: ');
r2 = kx * input('The second corner: ');
r3 = kx * input('The third corner: ');
r4 = kx * input('The fourth corner: ');

b =  (rstar./r1 + rstar./r2 + rstar./r3 + rstar./r4)/4 - 1;
A = [rstar rstar.^2];
k = A\b
