#include <libgimp/gimp.h>
#include <stdio.h>
#include <stdlib.h>
#include "main.h"
/* Function prototypes */

typedef struct _Img {
	guchar *data;
	int width;
	int height;
} Img;

typedef struct _Pix {
	guchar r;
	guchar g;
	guchar b;
	guchar a;
} Pix;

typedef struct _Point {
	gdouble x;
	gdouble y;
} Point;

typedef struct _Lconst {
	gdouble k1;
	gdouble k2;
} Lconst;

Point point_new(gdouble x, gdouble y) {
	Point p;
	p.x = x;
	p.y = y;
	return p;
}

Point *point_newp(gdouble x, gdouble y) {
	Point *p = g_new(Point, 1);
	p->x = x;
	p->y = y;
	return p;
}

int img_off(Img *i, int x, int y) {
	return ((y * i->width) + x)*sizeof(Pix);
}

int shift(int val, int width) {
	return val + width/2;
}

int unshift(int val, int width) {
	return val - width/2;
}

gdouble dist_L(gdouble r, Lconst l) {
	return 1 + l.k1 * r + l.k2 * r*r;
}

Point translate(Point p, Img i, gdouble lenswidth, gdouble lensheight, 
		Lconst lc, gboolean comp_radial, gboolean comp_cyl) {
	gdouble l;
	//gdouble xmax = 0.49;
	gdouble xmax = lenswidth;
	double kx = xmax / (i.width / 2.0);
	//double ky = ymax / (i.height / 2.0);
	static double rmax = 0.0;
	gdouble vx = p.x * kx;
	gdouble r = sqrt(p.y*p.y*kx*kx + (p.x)*(p.x)*kx*kx);
	gdouble s = sqrt(1.0 + vx * vx);	

	if (r > rmax) {
		rmax = r;
		printf("rmax=%g(%g,%g)\n", rmax, xmax,kx);
	}

	// ###  radial distortion  ###
	if (comp_radial) {
		l = dist_L(r, lc);
		//printf("l= %g\n", l);
		//printf("px= %g\n", p.x);
		p.x /= l;
		p.y /= l;
		//printf("_px= %g\n", p.x);
	}


	// ###  v�ran kamera  ###
	if (comp_cyl) {
		p.x = tan(p.x * kx) / kx;
		//p.x = tan(p.x * kx) * (i.width / 2.0) / xmax;
		p.y *= s;
	}

	return p;
}

Pix img_get(Img *src, Point p) {
	Pix pix = { 0, 0, 0, 0};
	int src_off;
	int ay, by;
	int ax, bx;
	int i, j;
	double fx, fy;
	double x1, x2;
	double y1, y2;
	double area;
	double pr = 0.0, pg = 0.0, pb = 0.0, pa = 0.0;

	x1 = p.x + src->width / 2;
	x2 = p.x + 1.0 + src->width / 2;
	y1 = p.y + src->height / 2;
	y2 = p.y + 1.0 + src->height / 2;
	ay = floor(y1);
	by = ceil(y2);
	ax = floor(x1);
	bx = ceil(x2);
	if (x1 < 0.0 || x2 > src->width)
		return pix;
	if (x1 < 0.0)
		x1 = 0.0;
	if (x2 > src->width)
		x2 = src->width;

	if (y1 < 0.0 || y2 > src->height)
		return pix;
	if (y1 < 0.0)
		y1 = 0.0;
	if (y2 > src->height)
		y2 = src->height;
	for (j = ax; j < bx; j ++) {
		fx = 1.0;
		if (j < x1)
			fx -= x1 - j;
		if (x2 - j < 1.0)
			fx -= 1.0 - (x2 - j);
		
		for (i = ay; i < by; i ++) {
			fy = 1.0;
			if (i < y1)
				fy -=y1 - i;
			if (y2 - i < 1.0)
				fy -= 1.0 - (y2 - i);

			src_off = img_off(src, j, i);
			pr += fx * fy * src->data[src_off + 0];
			pg += fx * fy * src->data[src_off + 1];
			pb += fx * fy * src->data[src_off + 2];
			pa += fx * fy * src->data[src_off + 3];
		}
	}
	area = (y2 - y1) * (x2 - x1);
	if (pg / area > 256.0) { // lite marginal vill vi kankse ha..
		printf("Konstig, den �r f�rstor: %f\n", pg / area);
		printf("ax=%d bx=%d ay=%d by=%d\nx1=%g x2=%g y1=%g y2=%g\n",
				ax,bx,ay,by,x1,x2,y1,y2);
		exit(5);
		/*pix.r = 50; pix.g = 255; pix.b = 50; pix.a = 255;*/
	} else {
		pix.r = MIN(pr / area, 255);
		pix.g = MIN(pg / area, 255);
		pix.b = MIN(pb / area, 255);
		pix.a = MIN(pa / area, 255);
	}
	return pix;
}

void img_set(Img *dst, Pix pix, int x, int y) {
	int dst_off = img_off(dst, shift(x, dst->width), shift(y, dst->height));
	dst->data[dst_off + 0] = pix.r;
	dst->data[dst_off + 1] = pix.g;
	dst->data[dst_off + 2] = pix.b;
	dst->data[dst_off + 3] = pix.a;
}


void enfish_layer(gint32 drawable, gdouble lenswidth,
		Lconst lc, gboolean comp_radial, gboolean comp_cyl) {
	int i;
	int j;
	Img *src = g_new(Img, 1);
	Img *dst = g_new(Img, 1);
	GimpDrawable *drawablep = gimp_drawable_get(drawable);
	GimpPixelRgn pr_src;
	GimpPixelRgn pr_dst;
	Pix pix;
	Point psource;
	Point p;

	if (!gimp_drawable_has_alpha(drawable)) {
		gimp_layer_add_alpha(drawable);
	}
	drawablep = gimp_drawable_get(drawable);
	
	dst->width = src->width = gimp_drawable_width(drawable);
	dst->height = src->height = gimp_drawable_height(drawable);
	src->data = g_new(char, src->width * src->height * sizeof(Pix));
	dst->data = g_new(char, dst->width * dst->height * sizeof(Pix));
	gimp_pixel_rgn_init(&pr_src, drawablep, 0, 0, src->width, src->height,
			FALSE, FALSE);
	gimp_pixel_rgn_init(&pr_dst, drawablep, 0, 0, dst->width,
			dst->height, TRUE, FALSE);
	//memcpy(src->data, dst->data, src->width * src->height * sizeof(Pix));
	gimp_pixel_rgn_get_rect(&pr_src, src->data, 0, 0, 
			src->width, src->height);
	for (j = -dst->height/2 ; j < dst->height/2 ; j++) {
		for (i = -dst->width/2 ; i < dst->width/2 ; i++) {
			p.x = i;
			p.y = j;
			psource = translate(p, *src, lenswidth, lenswidth,
					lc, comp_radial, comp_cyl);
			pix = img_get(src, psource);
			img_set(dst, pix, p.x, p.y);

		}
	}
	gimp_pixel_rgn_set_rect(&pr_dst, dst->data, 0, 0, 
			dst->width, dst->height);
	gimp_drawable_flush(drawablep);
	//gimp_drawable_merge_shadow(drawable, TRUE);
	gimp_drawable_update(drawable, 0, 0, dst->width, dst->height);
	gimp_drawable_detach(drawablep);
	g_free(src->data);
	g_free(dst->data);
	g_free(src);
	g_free(dst);
}

void enfish(gint32 image, gint32 drawable, PlugInVals *params) {
	int i;
	Lconst l;
	gint *layers;
	gint nlayers;
	gdouble progress;
	gchar *prog_label = "enfish (fish is good for you)";
	gimp_image_undo_group_start(image);
	gimp_progress_init(prog_label);
	layers = gimp_image_get_layers(image, &nlayers);
	l.k1 = params->k1;
	l.k2 = params->k2;
	if (params->all_layers_active && nlayers != 1) {
		for (i = nlayers - 2; i >= 0; i--) {
			progress = 1.0 - i/(double)(nlayers -1);
			enfish_layer(layers[i], params->lenswidth / 2.0, l, 
					params->comp_radial, params->comp_cyl);
			gimp_progress_update(progress);
		}
	} else {
		enfish_layer(drawable, params->lenswidth / 2.0, l,
				params->comp_radial, params->comp_cyl);
	}
	gimp_image_undo_group_end(image);
	gimp_progress_update(100.0);
}

