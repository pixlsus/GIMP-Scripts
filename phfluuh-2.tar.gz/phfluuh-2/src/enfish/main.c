/* The GIMP -- an image manipulation program
 * Copyright (C) 1995-1997 Spencer Kimball and Peter Mattis
 *
 * GIMP Plug-In Template
 * Copyright (C) 2000  Michael Natterer <mitch@gimp.org>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#define HAVE_NLS

#include <libgimp/gimp.h>
#include <libgimp/gimpui.h>

#include "interface.h"
#include "main.h"
#include <string.h>

#include "plugin-intl.h"


/*  Constants  */

#define PROCEDURE_NAME   PLUGIN_NAME

#define DATA_KEY_VALS    "plug_in_enfish"

#define PARASITE_KEY     "plug-in-enfish-options"


/*  Local function prototypes  */

static void   query (void);
static void   run   (const gchar      *name,
		     gint        nparams,
		     const GimpParam  *param,
		     gint       *nreturn_vals,
		     GimpParam **return_vals);


/*  Local variables  */

const PlugInVals default_vals =
{
    0.78,
    0.01,
    0.0055,
    TRUE,
    TRUE,
    TRUE
};


static PlugInVals         vals;


GimpPlugInInfo PLUG_IN_INFO =
{
  NULL,  /* init_proc  */
  NULL,  /* quit_proc  */
  query, /* query_proc */
  run,   /* run_proc   */
};

MAIN ()

static void
query (void)
{
    static GimpParamDef args[] =
    {
        { GIMP_PDB_INT32,    "run_mode",   "Interactive, non-interactive"    },
        { GIMP_PDB_IMAGE,    "image",      "Input image"                     },
        { GIMP_PDB_DRAWABLE, "drawable",   "Input drawable"                  },
        { GIMP_PDB_FLOAT,    "lenswidth",  "Lens width"                      },
        { GIMP_PDB_FLOAT,    "k1",  "Radial distortion constans k1"          },
        { GIMP_PDB_FLOAT,    "k2",  "Radial distortion constans k2"          },
        { GIMP_PDB_INT8,     "comp_radial", "Compensate for radial distortion"},
        { GIMP_PDB_INT8,     "comp_cyl", "Compensate for cylinder maping"    },
        { GIMP_PDB_INT8,     "all_layers", "Process all layers"              }
    };
    static gint nargs = sizeof (args) / sizeof (args[0]);

    //gimp_plugin_domain_register (PLUGIN_NAME, LOCALEDIR);
    //gimp_plugin_help_register (DATADIR"/help");


    gimp_install_procedure(
            PLUGIN_NAME,
            "adds some fishes",
            "help",
            "androman, janlert, stric @ acc.umu.se",
            "free for all (GPL)",
            "2001",
            "<Image>/Filters/Map/Enfish ...", 
            "RGBA,RGB",
            GIMP_PLUGIN,
            nargs,
            0,
            args,
            NULL);

}

static void
run (const gchar      *name, 
        gint        n_params, 
        const GimpParam  *param, 
        gint       *nreturn_vals,
        GimpParam **return_vals)
{
    static GimpParam   values[1];
    GimpDrawable      *drawable;
    gint32             image_ID;
    gint32             drwint;
    GimpRunMode    run_mode;
    GimpPDBStatusType  status = GIMP_PDB_SUCCESS;

    *nreturn_vals = 1;
    *return_vals  = values;

    run_mode = param[0].data.d_int32;
    image_ID = param[1].data.d_int32;
    drawable = gimp_drawable_get (param[2].data.d_drawable);
    drwint = param[2].data.d_drawable;

    /*  Initialize with default values  */
    vals          = default_vals;

    if (strcmp (name, PROCEDURE_NAME) == 0)
    {
        switch (run_mode)
        {
            case GIMP_RUN_NONINTERACTIVE:
                if (n_params != 8)
                {
                    status = GIMP_PDB_CALLING_ERROR;
                }
                else
                {
                    vals.lenswidth    = param[3].data.d_float;
		    vals.k1 = param[5].data.d_float;
		    vals.k2 = param[6].data.d_float;
                    vals.comp_radial     = param[8].data.d_int8;
                    vals.comp_cyl     = param[9].data.d_int8;
                    vals.all_layers_active     = param[10].data.d_int8;
                }
                break;

            case GIMP_RUN_INTERACTIVE:
                /*  Possibly retrieve data  */
                gimp_get_data (DATA_KEY_VALS,    &vals);

                if (! dialog (image_ID, drawable,
                            &vals))
                {
                    status = GIMP_PDB_CANCEL;
                }
                break;

            case GIMP_RUN_WITH_LAST_VALS:
                /*  Possibly retrieve data  */
                gimp_get_data (DATA_KEY_VALS, &vals);
                break;

            default:
                break;
        }
    }
    else
    {
	g_message("jag heter inte %s", name);
        status = GIMP_PDB_CALLING_ERROR;
    }

    if (status == GIMP_PDB_SUCCESS)
    {
        enfish (image_ID, drwint, &vals);

        if (run_mode != GIMP_RUN_NONINTERACTIVE)
            gimp_displays_flush ();

        if (run_mode == GIMP_RUN_INTERACTIVE)
        {
            gimp_set_data (DATA_KEY_VALS,    &vals,    sizeof (vals));
        }

        gimp_drawable_detach (drawable);
    }

    values[0].type = GIMP_PDB_STATUS;
    values[0].data.d_status = status;
}
