/* The GIMP -- an image manipulation program
 * Copyright (C) 1995 Spencer Kimball and Peter Mattis
 *
 * GIMP Plug-in Template
 * Copyright (C) 2000  Michael Natterer <mitch@gimp.org>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */


#include <libgimp/gimp.h>
#include <stdlib.h>
#include <libgimp/gimpui.h>

#include "interface.h"
#include "main.h"

#include "plugin-intl.h"

/*  Local function prototypes  */


/*  Local variables  */

static PlugInVals *ui_state    = NULL;

static GtkWidget    *chkbox_all  = NULL;
static GtkWidget    *chkbox_comp_radial  = NULL;
static GtkWidget    *chkbox_comp_cyl  = NULL;
static GtkWidget    *lenswidth    = NULL;
static GtkWidget    *wid_k1    = NULL;
static GtkWidget    *wid_k2    = NULL;

static gboolean      run         = FALSE;


/*  Public functions  */

gboolean
dialog (gint32              image_ID,
        GimpDrawable       *drawable,
        PlugInVals         *vals)
{
    GtkWidget *dlg;
    GtkWidget *main_vbox;
    GtkWidget *frame;
    GtkWidget *hbox, *vbox;
    GtkWidget *lab;
    GtkWidget *sep;
    GtkWidget *klab;
    gint       row;
    char *locale;
    const char* str;

    ui_state = vals;

    gimp_ui_init (PLUGIN_NAME, TRUE);

    dlg = gimp_dialog_new ("DeFishy", PLUGIN_NAME,
            NULL, 0,
            gimp_standard_help_func,
               PLUGIN_NAME".html", 
	    GTK_STOCK_CANCEL,GTK_RESPONSE_CANCEL,
	    GTK_STOCK_OK, GTK_RESPONSE_OK, 
            NULL);

//    gtk_signal_connect (GTK_OBJECT (dlg), "destroy",
//           GTK_SIGNAL_FUNC (gtk_main_quit),
//           NULL);

    /*  Initialize tooltips  */
    /* gimp_help_init (); */

    main_vbox = gtk_vbox_new (FALSE, 1);
    gtk_container_set_border_width (GTK_CONTAINER (main_vbox), 1);
    gtk_container_add (GTK_CONTAINER (GTK_DIALOG (dlg)->vbox), main_vbox);


    frame = gtk_frame_new (_("Stuff you need to set"));
    gtk_container_add (GTK_CONTAINER (main_vbox), frame);
    vbox = gtk_vbox_new(FALSE, 1);
    gtk_container_set_border_width (GTK_CONTAINER (vbox), 1);
    gtk_container_add (GTK_CONTAINER (frame), vbox);

    hbox = gtk_hbox_new (FALSE, 1);
    gtk_container_set_border_width(GTK_CONTAINER(hbox), 1);
    gtk_container_add (GTK_CONTAINER (vbox), hbox);
    lab = gtk_label_new ("Lens width:");
    gtk_container_add(GTK_CONTAINER (hbox), lab);
    gtk_widget_show(lab);
    lenswidth = gtk_entry_new();
    locale = setlocale(LC_NUMERIC, "C");
    gtk_entry_set_text(GTK_ENTRY(lenswidth), 
		    g_strdup_printf("%f", vals->lenswidth));
    setlocale(LC_NUMERIC, locale);
    gtk_container_add(GTK_CONTAINER (hbox), lenswidth);
    gtk_widget_show(hbox);

    chkbox_comp_radial = gtk_check_button_new_with_label ("Compensate for radial distortion");
    gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(chkbox_comp_radial),
            vals->comp_radial);
    gtk_container_add(GTK_CONTAINER (vbox), chkbox_comp_radial);

    chkbox_comp_cyl = gtk_check_button_new_with_label ("Compensate for cylinder maping");
    gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(chkbox_comp_cyl),
            vals->comp_cyl);
    gtk_container_add(GTK_CONTAINER (vbox), chkbox_comp_cyl);


    chkbox_all = gtk_check_button_new_with_label ("Apply on all layers");
    gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(chkbox_all),
            vals->all_layers_active);
    gtk_container_add(GTK_CONTAINER (vbox), chkbox_all);

    sep = gtk_hseparator_new();
    gtk_container_add(GTK_CONTAINER (vbox), sep);
    gtk_widget_show(sep);
    klab = gtk_label_new("Constants for radial distortion");
    gtk_container_add(GTK_CONTAINER (vbox), klab);
    gtk_widget_show(klab);


    hbox = gtk_hbox_new (FALSE, 1);
    gtk_container_set_border_width(GTK_CONTAINER(hbox), 1);
    gtk_container_add (GTK_CONTAINER (vbox), hbox);
    lab = gtk_label_new ("k1:");
    gtk_container_add(GTK_CONTAINER (hbox), lab);
    gtk_widget_show(lab);
    wid_k1 = gtk_entry_new();
    locale = setlocale(LC_NUMERIC, "C");
    gtk_entry_set_text(GTK_ENTRY(wid_k1), 
		    g_strdup_printf("%g", vals->k1));
    setlocale(LC_NUMERIC, locale);
    gtk_container_add(GTK_CONTAINER (hbox), wid_k1);
    gtk_widget_show(hbox);

    hbox = gtk_hbox_new (FALSE, 1);
    gtk_container_set_border_width(GTK_CONTAINER(hbox), 1);
    gtk_container_add (GTK_CONTAINER (vbox), hbox);
    lab = gtk_label_new ("k2:");
    gtk_container_add(GTK_CONTAINER (hbox), lab);
    gtk_widget_show(lab);
    wid_k2 = gtk_entry_new();
    locale = setlocale(LC_NUMERIC, "C");
    gtk_entry_set_text(GTK_ENTRY(wid_k2), 
		    g_strdup_printf("%g", vals->k2));
    setlocale(LC_NUMERIC, locale);
    gtk_container_add(GTK_CONTAINER (hbox), wid_k2);
    gtk_widget_show(hbox);

    gtk_widget_show(hbox);
    gtk_widget_show(chkbox_all);
    gtk_widget_show(chkbox_comp_radial);
    gtk_widget_show(chkbox_comp_cyl);
    gtk_widget_show(lenswidth);
    gtk_widget_show(wid_k1);
    gtk_widget_show(wid_k2);
    gtk_widget_show (frame);
    gtk_widget_show(vbox);

    gtk_widget_show(main_vbox);


    row = 0;

    /*  Show the main containers  */

    gtk_widget_show (main_vbox);
    gtk_widget_show (dlg);

//    gtk_main ();

    run = (gimp_dialog_run(GIMP_DIALOG(dlg)) == GTK_RESPONSE_OK);
    if (run) {
	    /*  Save ui values  */
	    if (chkbox_all) {
		    ui_state->all_layers_active = 
			    GTK_TOGGLE_BUTTON(chkbox_all)->active;
	    }
	    if (chkbox_comp_radial) {
		    ui_state->comp_radial = 
			    GTK_TOGGLE_BUTTON(chkbox_comp_radial)->active;
	    }
	    if (chkbox_comp_cyl) {
		    ui_state->comp_cyl = 
			    GTK_TOGGLE_BUTTON(chkbox_comp_cyl)->active;
	    }
	    if (lenswidth) {
		    str = gtk_entry_get_text (GTK_ENTRY(lenswidth));
		    ui_state->lenswidth = atof(str);
	    }
	    if (wid_k1) {
		    str = gtk_entry_get_text (GTK_ENTRY(wid_k1));
		    ui_state->k1 = atof(str);
	    }
	    if (wid_k2) {
		    str = gtk_entry_get_text (GTK_ENTRY(wid_k2));
		    ui_state->k2 = atof(str);
	    }
    }
    gtk_widget_destroy(dlg);
    /*  Free tooltips  */
    /* gimp_help_free (); */


    return run;
}



