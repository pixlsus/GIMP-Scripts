/* The GIMP -- an image manipulation program
 * Copyright (C) 1995-1997 Spencer Kimball and Peter Mattis
 *
 * GIMP Plug-In Template
 * Copyright (C) 2000  Michael Natterer <mitch@gimp.org>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#define HAVE_NLS

#include <libgimp/gimp.h>
#include <libgimp/gimpui.h>
#include <string.h>

#include "interface.h"
#include "main.h"

#include "plugin-intl.h"


/*  Constants  */

#define PROCEDURE_NAME   PLUGIN_NAME

#define DATA_KEY_VALS    "plug_in_lineup"

#define PARASITE_KEY     "plug-in-lineup-options"


/*  Local function prototypes  */

static void   query (void);
static void   run   (const gchar      *name,
		     gint        nparams,
		     const GimpParam  *param,
		     gint       *nreturn_vals,
		     GimpParam **return_vals);


/*  Local variables  */

const PlugInVals default_vals = {"a1.jpg|a2.jpg"};


static PlugInVals         vals;


GimpPlugInInfo PLUG_IN_INFO =
{
  NULL,  /* init_proc  */
  NULL,  /* quit_proc  */
  query, /* query_proc */
  run,   /* run_proc   */
};

MAIN ()

static void
query (void)
{
    static GimpParamDef args[] =
    {
        { GIMP_PDB_INT32,    "run_mode",   "Interactive, non-interactive"    },
	{ GIMP_PDB_STRINGARRAY, "file", "File containing filenames to line up, one per line, lines starting width # are comments, blanks are ignored" }
    };
    static gint nargs = sizeof (args) / sizeof (args[0]);

    //gimp_plugin_domain_register (PLUGIN_NAME, LOCALEDIR);
    //gimp_plugin_help_register (DATADIR"/help");


    gimp_install_procedure(
            PLUGIN_NAME,
            "Lines up some files",
            "help",
            "androman, janlert, stric @ acc.umu.se",
            "free for all (GPL)",
            "2001",
            "<Toolbox>/Xtns/Lineup", 
            "",
            GIMP_EXTENSION,
            nargs,
            0,
            args,
            NULL);

}

static void
run (const gchar      *name, 
        gint        n_params, 
        const GimpParam  *param, 
        gint       *nreturn_vals,
        GimpParam **return_vals)
{
    static GimpParam   values[1];
    GimpRunMode    run_mode;
    GimpPDBStatusType  status = GIMP_PDB_SUCCESS;
    char buf[1024];
    char *file;

    *nreturn_vals = 1;
    *return_vals  = values;

    run_mode = param[0].data.d_int32;
    file = param[1].data.d_string;

    /*  Initialize with default values  */
    vals          = default_vals;

    if (strcmp (name, PROCEDURE_NAME) == 0)
    {
        switch (run_mode)
        {
            case GIMP_RUN_NONINTERACTIVE:
                if (n_params != 8)
                {
                    status = GIMP_PDB_CALLING_ERROR;
                }
                else
                {
                    vals.file = param[1].data.d_string;
                }
                break;

            case GIMP_RUN_INTERACTIVE:
                /*  Possibly retrieve data  */
                gimp_get_data (DATA_KEY_VALS,    &buf);
		buf[1023] = '\0';
		if (strlen(buf))
			vals.file = g_strdup(buf);
		//printf("LADDAR: %s\n", vals.file);

                if (! dialog ( &vals))
                {
                    status = GIMP_PDB_CANCEL;
                }
                break;

            case GIMP_RUN_WITH_LAST_VALS:
                /*  Possibly retrieve data  */
                gimp_get_data (DATA_KEY_VALS,    &buf);
		buf[1023] = '\0';
		if (strlen(buf))
			vals.file = g_strdup(buf);
                break;

            default:
                break;
        }
    }
    else
    {
	g_message("jag heter inte %s", name);
        status = GIMP_PDB_CALLING_ERROR;
    }

    if (status == GIMP_PDB_SUCCESS)
    {
	    //files = g_strsplit(g_strdup(vals.files), "|", 0);
	    lineup (vals.file);

        if (run_mode != GIMP_RUN_NONINTERACTIVE)
            gimp_displays_flush ();

        if (run_mode == GIMP_RUN_INTERACTIVE)
        {
		//printf("SPARAR: %s\n", vals.file);
            gimp_set_data (DATA_KEY_VALS, vals.file, strlen(vals.file) + 1);
        }

    }

    values[0].type = GIMP_PDB_STATUS;
    values[0].data.d_status = status;
}
