/* The GIMP -- an image manipulation program
 * Copyright (C) 1995 Spencer Kimball and Peter Mattis
 *
 * GIMP Plug-in Template
 * Copyright (C) 2000  Michael Natterer <mitch@gimp.org>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */


#include <libgimp/gimp.h>
#include <libgimp/gimpui.h>

#include "interface.h"
#include "main.h"

#include "plugin-intl.h"


static PlugInVals *ui_state    = NULL;

static gboolean      run         = FALSE;


void fsel_cb(GtkWidget *widget, gpointer user_data) {
	GtkFileSelection *fs = (GtkFileSelection*)user_data;
	const char *file;
	if (!fs) {
		//printf("Cancel\n");
		ui_state->file = NULL;
		gtk_main_quit();
		return;
	} 
	file = gtk_file_selection_get_filename(fs);
	//printf("Got file %s\n", file);
	ui_state->file = g_strdup(file);
	gtk_widget_destroy(GTK_WIDGET(fs));
	run = TRUE;
}


/*  Public functions  */

gboolean
dialog ( PlugInVals         *vals)
{
    GtkWidget *fsel;

    ui_state = vals;

    gimp_ui_init (PLUGIN_NAME, TRUE);


    /*  Initialize tooltips  */
    /* gimp_help_init (); */

    fsel = gtk_file_selection_new("Select file containing filenames");
    gtk_widget_show(fsel);
    gtk_signal_connect (GTK_OBJECT (fsel), "destroy",
		    GTK_SIGNAL_FUNC (gtk_main_quit),
		    NULL);

    gtk_signal_connect (GTK_OBJECT(GTK_FILE_SELECTION(fsel)->ok_button),
		    "clicked", GTK_SIGNAL_FUNC (fsel_cb), 
		    GTK_OBJECT(fsel));  
    gtk_signal_connect (GTK_OBJECT(GTK_FILE_SELECTION( fsel)->cancel_button),
		    "clicked", GTK_SIGNAL_FUNC (fsel_cb), NULL);  
    gtk_main ();
    /*  Free tooltips  */
    /* gimp_help_free (); */
    return run;
}


