#include <libgimp/gimp.h>
#include <strings.h>
#include <stdio.h>
#include <string.h>

gint32 insert_image(char *filename, gint32 pan_id) {
	gint32 image_id;
	gint32 d;
	gint32 newlayer;
	gint32 paste;
	int width, height;
	int pan_width, pan_height;
	image_id = gimp_file_load(GIMP_RUN_NONINTERACTIVE, filename, filename);
	//printf("image: %d\n", image_id);
	d = gimp_image_get_active_drawable(image_id);
	gimp_edit_copy(d);
	width = gimp_drawable_width(d);
	height = gimp_drawable_height(d);
	pan_width = gimp_image_width(pan_id);
	pan_height = gimp_image_height(pan_id);
	gimp_image_resize(pan_id, pan_width+width, MAX(pan_height,height), 0,0);

	newlayer = gimp_layer_new(pan_id, filename, width, height,
			GIMP_RGBA_IMAGE, 100.0, GIMP_NORMAL_MODE);
	gimp_image_add_layer(pan_id, newlayer, -1);
	paste = gimp_edit_paste(newlayer, 1);
	gimp_floating_sel_anchor(paste);
	gimp_layer_translate(newlayer, pan_width, 0);

	gimp_image_delete(image_id);
	return d;
}

void lineup(char *files) {

	FILE *f = fopen(files, "r");
	char buf[1024];
	gint32 pan_id;
	char *nl;
	gint32 bkg;
	int border, width, height;
	int i = 0;
	if (!f) {
		g_message("error opening file file");
		return;
	}
	pan_id = gimp_image_new(1, 1, GIMP_RGB);
	gimp_image_undo_group_start(pan_id);
	bkg = gimp_layer_new(pan_id, "bkg", 1, 1, GIMP_RGBA_IMAGE,
			100.0, GIMP_NORMAL_MODE);
	gimp_image_add_layer(pan_id, bkg, 0);
	while (fgets(buf, 1024, f)) {
		if (buf[0] == '#' || buf[0] == '\n')
			continue;
		nl = strchr(buf, '\n');
		if (nl) // chop newline
			*nl = '\0';

		insert_image(buf, pan_id);
		i++;
	}
	//insert_image("1.jpg", pan_id);
	if (i != 0) {
		gimp_display_new(pan_id);

		width = gimp_image_width(pan_id);
		height = gimp_image_height(pan_id);
		border = height * 0.2;
		gimp_image_resize(pan_id, width + border, height + border, 
				border / 2, border / 2);
	}
	gimp_image_undo_group_end(pan_id);
	gimp_displays_flush();
}

